<?php
// connecting to database
include 'connect.php';

$login = false;

// collecting data from form and storing in the variables
if (isset($_POST['loginin_submit'])) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $user_email = $_POST['user_email'];
        $user_password = $_POST['user_password'];
        // checking the existance of user in our database
        $sql = "SELECT * FROM `login` WHERE email_id='$user_email'";
        $result = mysqli_query($conn,$sql);

        if (mysqli_num_rows($result) == 1) {
            while ($row = mysqli_fetch_assoc($result)) {
                if (password_verify($user_password, $row['password'])) {
                    // echo "Log in successful!";
                    session_start();
                    $_SESSION['login'] = true;
                    $_SESSION['login_user_id'] = $row['password'];
                    header("location: /dashboard");
                } else {
                    echo "login ussuccessful!";
                }
            }
        } 
        // else {
        //     echo "Log in unsuccessful! Sign in first";
        // }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/register.css">
</head>
<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form action="" >
                    <h2>login</h2>
                    <div class="inputbox">
                        <ion-icon name="mail-outline"></ion-icon>
                        <input type="email" name="user_email" required>
                        <label for="">Email</label>
                    </div>
                    <div class="inputbox">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="user_password" required>
                        <label for="">Password</label>
                    </div>
                    <button type="submit" name="loginin_submit"><a>Log in</a> </button>
                    <div class="Register">
                        <p>dont have an account <button><a href="register.html">Register</a></button></p>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
